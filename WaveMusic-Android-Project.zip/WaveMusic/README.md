# Wave Music

Native Android music player starter: Kotlin, Jetpack Compose and AndroidX Media3.

## Included
- Device audio discovery using Android MediaStore.
- Media3 ExoPlayer with MediaSessionService for background playback and system media controls.
- Song list, search, previous/next, seek bar and playback controls.
- LRCLIB lyric lookup: synchronized LRC first, plain lyrics fallback.
- Karaoke-style active-line highlighting.
- GitHub Actions workflow for building a debug APK.

## Build
Open the project in Android Studio with JDK 17 and run `gradle assembleDebug`.
APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Build from a phone using GitHub
1. Upload the project files to a GitHub repository.
2. Open the repository's Actions tab.
3. Run **Build Wave Music APK** (or push to `main` / `master`).
4. Download the `Wave-Music-debug-apk` artifact from the completed workflow.

## Notes
- First launch requests permission to read local audio.
- Internet access is used for lyrics lookup. LRCLIB may not have every song.
- When only plain lyrics are available, line timing is approximate; synchronized LRC is preferred.
- Local LRC file import, artwork extraction, favorites persistence, playlists and equalizer are not included yet.
