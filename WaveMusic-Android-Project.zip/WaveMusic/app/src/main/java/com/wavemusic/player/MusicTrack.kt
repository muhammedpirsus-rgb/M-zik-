package com.wavemusic.player

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore

data class MusicTrack(
    val id: Long, val title: String, val artist: String,
    val album: String, val duration: Long, val uri: android.net.Uri
)

fun loadDeviceSongs(context: Context): List<MusicTrack> {
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION
    )
    val result = mutableListOf<MusicTrack>()
    context.contentResolver.query(
        collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0",
        null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
    )?.use { c ->
        val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val album = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val duration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        while (c.moveToNext()) {
            val songId = c.getLong(id)
            result += MusicTrack(
                songId, c.getString(title) ?: "Bilinmeyen şarkı",
                c.getString(artist)?.takeUnless { it == "<unknown>" } ?: "Bilinmeyen sanatçı",
                c.getString(album) ?: "", c.getLong(duration),
                ContentUris.withAppendedId(collection, songId)
            )
        }
    }
    return result
}

fun formatTime(ms: Long): String {
    val s = (ms.coerceAtLeast(0) / 1000).toInt()
    return "%d:%02d".format(s / 60, s % 60)
}
