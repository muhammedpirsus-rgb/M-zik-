package com.wavemusic.player

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class LyricLine(val timeMs: Long, val text: String)

object LyricsRepository {
    suspend fun find(track: MusicTrack): List<LyricLine> = withContext(Dispatchers.IO) {
        val a = enc(track.artist)
        val t = enc(track.title)
        val album = enc(track.album)
        val duration = track.duration / 1000
        val urls = listOf(
            "https://lrclib.net/api/get?artist_name=$a&track_name=$t&album_name=$album&duration=$duration",
            "https://lrclib.net/api/search?track_name=$t&artist_name=$a"
        )
        for (address in urls) {
            try {
                val conn = (URL(address).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 7000
                    readTimeout = 7000
                    setRequestProperty("User-Agent", "WaveMusic/1.0 Android")
                }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val obj = if (body.trimStart().startsWith("[")) {
                    val arr = org.json.JSONArray(body)
                    if (arr.length() == 0) continue
                    arr.getJSONObject(0)
                } else JSONObject(body)
                val synced = obj.optString("syncedLyrics")
                val parsed = parseLrc(synced)
                if (parsed.isNotEmpty()) return@withContext parsed
                val plain = obj.optString("plainLyrics")
                if (plain.isNotBlank()) return@withContext plain.lines()
                    .filter { it.isNotBlank() }
                    .mapIndexed { i, line -> LyricLine(i * 4000L, line) }
            } catch (_: Exception) { }
        }
        emptyList()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun parseLrc(text: String): List<LyricLine> {
        val pattern = Regex("""\[(\d{2}):(\d{2})(?:\.(\d{1,3}))?]""")
        return text.lines().mapNotNull { line ->
            val m = pattern.find(line) ?: return@mapNotNull null
            val min = m.groupValues[1].toLong()
            val sec = m.groupValues[2].toLong()
            val frac = m.groupValues[3].padEnd(3, '0').take(3).ifBlank { "000" }.toLong()
            val lyric = line.substring(m.range.last + 1).trim()
            if (lyric.isBlank()) null
            else LyricLine((min * 60 + sec) * 1000 + frac, lyric)
        }.sortedBy { it.timeMs }
    }
}
