package com.wavemusic.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Bg = Color(0xFF090A12)
private val Panel = Color(0xFF171827)
private val Purple = Color(0xFF9B7BFF)
private val Muted = Color(0xFF9293A8)

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var allowed by mutableStateOf(false)
    private val askPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        allowed = it
        if (it) connect()
        render()
    }

    private fun permission() = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        allowed = ContextCompat.checkSelfPermission(this, permission()) == PackageManager.PERMISSION_GRANTED
        if (allowed) connect()
        render()
        if (!allowed) askPermission.launch(permission())
    }

    private fun connect() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ controller = future.get() }, MoreExecutors.directExecutor())
    }

    private fun render() {
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Purple, background = Bg, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )) {
                if (!allowed) PermissionScreen { askPermission.launch(permission()) }
                else WaveApp(controller)
            }
        }
    }

    override fun onDestroy() {
        controller?.release()
        controller = null
        super.onDestroy()
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Bg).padding(28.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Icon(Icons.Default.LibraryMusic, null, tint = Purple, modifier = Modifier.size(64.dp))
            Text("Müziklerine ulaşalım", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Wave Music, telefonundaki ses dosyalarını listelemek ve çalmak için müzik izni ister.", color = Muted)
            Button(onClick = onGrant) { Text("İzin ver") }
        }
    }
}

@Composable
private fun WaveApp(player: MediaController?) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var songs by remember { mutableStateOf(emptyList<MusicTrack>()) }
    var selected by remember { mutableStateOf<MusicTrack?>(null) }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var lyrics by remember { mutableStateOf(emptyList<LyricLine>()) }
    var loading by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun fetchLyrics(track: MusicTrack) {
        loading = true
        lyrics = emptyList()
        scope.launch {
            lyrics = LyricsRepository.find(track)
            loading = false
        }
    }

    fun play(index: Int) {
        val track = songs.getOrNull(index) ?: return
        selected = track
        val queue = songs.map { song ->
            MediaItem.Builder().setUri(song.uri).setMediaMetadata(
                MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist).build()
            ).build()
        }
        player?.setMediaItems(queue, index, 0L)
        player?.prepare()
        player?.play()
        playing = true
        fetchLyrics(track)
    }

    LaunchedEffect(Unit) { songs = loadDeviceSongs(context) }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val track = songs.getOrNull(player?.currentMediaItemIndex ?: -1)
                selected = track
                track?.let { fetchLyrics(it) }
            }
        }
        player?.addListener(listener)
        onDispose { player?.removeListener(listener) }
    }
    LaunchedEffect(player) {
        while (true) {
            position = player?.currentPosition ?: 0L
            duration = player?.duration?.takeIf { it > 0 } ?: (selected?.duration ?: 0L)
            delay(300)
        }
    }

    val activeLine = lyrics.indexOfLast { it.timeMs <= position }.coerceAtLeast(0)
    val filtered = songs.filter { it.title.contains(search, true) || it.artist.contains(search, true) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("W A V E", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("Music", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            }
            IconButton(onClick = { songs = loadDeviceSongs(context) }) {
                Icon(Icons.Default.Refresh, "Yenile")
            }
        }
        Row(Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(14.dp)).background(Panel).padding(4.dp)) {
            listOf("Şarkılar", "Karaoke sözler").forEachIndexed { i, label ->
                Box(Modifier.weight(1f).clip(RoundedCornerShape(11.dp))
                    .background(if (tab == i) Purple.copy(alpha = .22f) else Color.Transparent)
                    .clickable { tab = i }.padding(11.dp), contentAlignment = Alignment.Center) {
                    Text(label, color = if (tab == i) Purple else Muted, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (tab == 0) {
            OutlinedTextField(
                value = search, onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                placeholder = { Text("Şarkı veya sanatçı ara…") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true, shape = RoundedCornerShape(16.dp)
            )
            Text("${filtered.size} ŞARKI", color = Muted, fontSize = 11.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
                itemsIndexed(filtered, key = { _, song -> song.id }) { _, song ->
                    val chosen = selected?.id == song.id
                    Row(Modifier.fillMaxWidth().clickable { play(songs.indexOf(song)) }
                        .padding(horizontal = 18.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(46.dp).clip(RoundedCornerShape(13.dp))
                            .background(Brush.linearGradient(listOf(Purple.copy(.65f), Color(0xFF292B48)))),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MusicNote, null)
                        }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(song.title, color = if (chosen) Purple else Color.White,
                                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(song.artist, color = Muted, fontSize = 12.sp, maxLines = 1)
                        }
                        Text(formatTime(song.duration), color = Muted, fontSize = 12.sp)
                    }
                }
                if (filtered.isEmpty()) item {
                    Text("Müzik bulunamadı. Dosyaların cihazında kayıtlı olduğundan emin ol.",
                        color = Muted, modifier = Modifier.padding(24.dp))
                }
            }
        } else {
            LyricsScreen(selected, lyrics, loading, activeLine, Modifier.weight(1f))
        }
        if (selected != null) {
            MiniPlayer(selected!!, playing, position, duration,
                onPlay = { if (playing) player?.pause() else player?.play() },
                onSeek = { player?.seekTo(it) },
                onPrevious = { player?.seekToPreviousMediaItem() },
                onNext = { player?.seekToNextMediaItem() },
                onLyrics = { tab = 1 })
        } else {
            Text("Dinlemeye başlamak için bir şarkı seç", color = Muted, modifier = Modifier.padding(20.dp))
        }
    }
}

@Composable
private fun LyricsScreen(track: MusicTrack?, lines: List<LyricLine>, loading: Boolean, active: Int, modifier: Modifier = Modifier) {
    if (track == null) {
        Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Text("Önce bir şarkı seç", color = Muted) }
        return
    }
    Column(modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(22.dp))
        Text(track.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(track.artist, color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        when {
            loading -> CircularProgressIndicator(color = Purple)
            lines.isEmpty() -> Text("Bu şarkı için çevrimiçi söz bulunamadı.", color = Muted)
            else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 100.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                itemsIndexed(lines) { index, line ->
                    val selected = index == active
                    val color by animateColorAsState(if (selected) Color.White else Muted.copy(alpha = .48f), label = "lyric")
                    Text(line.text, color = color, fontSize = if (selected) 25.sp else 17.sp,
                        fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
                        lineHeight = if (selected) 34.sp else 25.sp,
                        modifier = Modifier.padding(vertical = 13.dp, horizontal = 12.dp))
                }
            }
        }
    }
}

@Composable
private fun MiniPlayer(
    track: MusicTrack, playing: Boolean, position: Long, duration: Long,
    onPlay: () -> Unit, onSeek: (Long) -> Unit, onPrevious: () -> Unit,
    onNext: () -> Unit, onLyrics: () -> Unit
) {
    Column(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(Purple.copy(.22f)),
                contentAlignment = Alignment.Center) { Icon(Icons.Default.Album, null, tint = Purple) }
            Column(Modifier.weight(1f).padding(start = 9.dp)) {
                Text(track.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, color = Muted, fontSize = 11.sp, maxLines = 1)
            }
            IconButton(onClick = onLyrics) { Icon(Icons.Default.Subtitles, "Sözler", tint = Purple) }
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Önceki") }
            IconButton(onClick = onPlay) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                    "Oynat veya duraklat", tint = Purple, modifier = Modifier.size(29.dp))
            }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Sonraki") }
        }
        Slider(
            value = position.coerceAtMost(duration.coerceAtLeast(1L)).toFloat(),
            onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
            modifier = Modifier.height(25.dp),
            colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), color = Muted, fontSize = 10.sp)
            Text(formatTime(duration), color = Muted, fontSize = 10.sp)
        }
    }
}
